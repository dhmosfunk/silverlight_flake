using System.Runtime.Serialization;

// These classes match the DataContract serialization format observed in the
// WCF SOAP traffic for SCToolkit2.Core.QuerySpec.
// Namespace and member names/order MUST match exactly for binary XML compatibility.

namespace SCToolkit2.Core
{
    [DataContract(Namespace = "http://schemas.datacontract.org/2004/07/SCToolkit2.Core")]
    public class QuerySpec
    {
        // DataContractSerializer serializes members in alphabetical order by default
        // unless Order is specified. Match the observed XML element order.

        [DataMember]
        public string CriteriaLogicalOperator { get; set; } = "AndOperator";

        [DataMember]
        public string? CustomFieldsToAddAfterLoad { get; set; }

        [DataMember]
        public bool Distinct { get; set; } = false;

        [DataMember]
        public string? ExportColumns { get; set; }

        [DataMember]
        public bool LongQuery { get; set; } = false;

        [DataMember]
        public int? OverrideDataSourceCode { get; set; }

        [DataMember]
        public string? OverrideEnvironment { get; set; }

        [DataMember]
        public bool OverrideOriginalSort { get; set; } = false;

        [DataMember]
        public string RetrievalMode { get; set; } = "AllRecords";

        [DataMember]
        public int RetrievePageSize { get; set; } = 0;

        [DataMember]
        public int RetrieveTopRecords { get; set; } = 0;

        [DataMember]
        public int RetrivePageNo { get; set; } = 0; // Note: typo matches original

        [DataMember]
        public string? SortSpec { get; set; }

        [DataMember]
        public int TotalPages { get; set; } = 0;

        [DataMember]
        public string? UniqueKey { get; set; }

        [DataMember]
        public bool UseParametrizeSQL { get; set; } = false;

        [DataMember]
        public Dictionary<string, FieldCriteria> _Criteria { get; set; } = new();

        [DataMember]
        public SQLParameters _SQLParameters { get; set; } = new();

        // --- Nested types ---

        [DataContract(Namespace = "http://schemas.datacontract.org/2004/07/SCToolkit2.Core")]
        public class FieldCriteria
        {
            [DataMember]
            public string FieldName { get; set; } = "";

            [DataMember]
            public bool OrNull { get; set; } = false;

            [DataMember]
            public SqlOperatorSpec SqlOperator { get; set; } = new();

            [DataMember]
            public object? Value { get; set; }
        }

        [DataContract(Namespace = "http://schemas.datacontract.org/2004/07/SCToolkit2.Core")]
        public class SqlOperatorSpec
        {
            [DataMember]
            public object? AdditionalValue { get; set; }

            [DataMember]
            public bool Negated { get; set; } = false;

            [DataMember]
            public string SqlOperator { get; set; } = "OP_EQ";
        }
    }

    [DataContract(Namespace = "http://schemas.datacontract.org/2004/07/SCToolkit2.Core")]
    public class SQLParameters
    {
        [DataMember]
        public Dictionary<string, object> _Parameters { get; set; } = new();
    }
}
